// Responsive
// $(document).ready(function() {
//     if ($('.body').width() <= 1024) {
//         console.log($('.body').width());
//         $('#firstServ').removeClass('col-md-offset-1');
//         $('#firstServ').removeClass('col-md-3');
//         $('#firstServ').addClass('col-md-4');
//     }
// })